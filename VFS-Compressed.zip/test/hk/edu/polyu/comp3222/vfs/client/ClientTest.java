package hk.edu.polyu.comp3222.vfs.client;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by ApplePuffs on 4/3/2017.
 */
public class ClientTest {
    @Test
    public void main() throws Exception {
        Client client = new Client();
        //client.main();
        //client.displaymenu();
    }

}