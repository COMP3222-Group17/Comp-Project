package hk.edu.polyu.comp3222.vfs.test;

import org.junit.Test;

import static org.junit.Assert.*;


public class CoreTest {
    @org.junit.Before
    public void setUp() throws Exception {

    }

    @Test
    public void testVirtualDiskCreation(){
        // ...
        assertTrue(1 == 1);
    }



}